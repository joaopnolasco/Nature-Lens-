// routes/itinerary.js
import express from 'express';
import { TextServiceClient } from '@google-ai/generativelanguage';
import { GoogleAuth } from 'google-auth-library';

const router = express.Router();

router.get('/:city', async (req, res) => {
  const city = req.params.city;

  try {
    if (!process.env.GOOGLE_API_KEY) {
      throw new Error('GOOGLE_API_KEY não está definida no arquivo .env');
    }

    const client = new TextServiceClient({
      authClient: new GoogleAuth().fromAPIKey(process.env.GOOGLE_API_KEY),
    });

    const prompt = {
      text: `Crie um itinerário detalhado de viagem de 3 dias para a cidade de ${city}, incluindo as principais atrações turísticas, restaurantes recomendados e dicas de transporte.`,
    };

    // Usando 'models/chat-bison-001'
    const [result] = await client.generateText({
      model: 'models/chat-bison-001',
      prompt,
    });

    const itinerary = result.candidates[0].output;

    res.json({ itinerary });
  } catch (error) {
    console.error('Erro ao obter o roteiro:', error);
    res.status(500).json({ error: 'Erro ao obter o roteiro', detalhes: error.message });
  }
});

export default router;
